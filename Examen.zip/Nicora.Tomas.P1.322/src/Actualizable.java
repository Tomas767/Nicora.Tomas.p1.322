interface Actualizable {
    void actualizarDatos();
}
