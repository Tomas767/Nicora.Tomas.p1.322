
public enum EstadoActual {
    EN_DESARROLLO,
    ESTRENANDO_MODELO,
    FINALIZADO,
}
