
public enum TipoAnalisis {
    DESCRIPTIVO,
    INFERENCIAL,
    PREDICTIVO,
}
